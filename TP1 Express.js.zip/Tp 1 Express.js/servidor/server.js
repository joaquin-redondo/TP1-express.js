const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Ruta base
app.get('/', (req, res) => {
  res.send('Servidor funcionando correctamente 🎉');
});

// Ruta de ejemplo con parámetro correcto
app.get('/api/usuario/:id', (req, res) => {
  const id = req.params.id;
  res.json({ mensaje: `Usuario con ID ${id}` });
});

// Ruta POST de ejemplo
app.post('/api/crear', (req, res) => {
  const datos = req.body;
  res.json({ mensaje: 'Datos recibidos correctamente', datos });
});

// Ruta no encontrada
app.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada' });
});

// Iniciar servidor
app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
